import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import FileUpload from "@/components/FileUpload";
import FileGallery from "@/components/FileGallery";
import { Button } from "@/components/ui/button";
import { Loader2, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { useLocation } from "wouter";

export default function Files() {
  const [, setLocation] = useLocation();
  const { isAuthenticated } = useAuth();
  const [isUploading, setIsUploading] = useState(false);

  // Fetch user files
  const { data: files = [], isLoading: isLoadingFiles, refetch } = trpc.files.list.useQuery();

  // Upload mutation
  const uploadMutation = trpc.files.upload.useMutation({
    onSuccess: () => {
      toast.success("File uploaded successfully!");
      refetch();
      setIsUploading(false);
    },
    onError: (error) => {
      toast.error(error.message || "Failed to upload file");
      setIsUploading(false);
    },
  });

  // Delete mutation
  const deleteMutation = trpc.files.delete.useMutation({
    onSuccess: () => {
      toast.success("File deleted successfully!");
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to delete file");
    },
  });

  const handleFileSelect = async (file: File, category: string, description: string) => {
    setIsUploading(true);

    try {
      // Read file as base64
      const reader = new FileReader();
      reader.onload = async (e) => {
        const base64 = (e.target?.result as string).split(",")[1];
        await uploadMutation.mutateAsync({
          fileName: file.name,
          fileData: base64,
          mimeType: file.type,
          category: category as any,
          description: description || undefined,
        });
      };
      reader.readAsDataURL(file);
    } catch (error) {
      toast.error("Failed to process file");
      setIsUploading(false);
    }
  };

  const handleDelete = (fileId: number) => {
    if (confirm("Are you sure you want to delete this file?")) {
      deleteMutation.mutate({ fileId });
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600 mb-4">Please sign in to manage files</p>
          <Button onClick={() => setLocation("/")} className="btn-neon">
            Go to Home
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-4">
            <Button
              onClick={() => setLocation("/")}
              variant="ghost"
              size="sm"
              className="gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back
            </Button>
            <h1 className="text-2xl font-bold" style={{ color: "#6B7280" }}>
              File Manager
            </h1>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-12">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Upload Section */}
          <div className="md:col-span-1">
            <div className="sticky top-24">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Upload Files</h2>
              <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
                <FileUpload
                  onFileSelect={handleFileSelect}
                  isLoading={isUploading || uploadMutation.isPending}
                />
              </div>
            </div>
          </div>

          {/* Files Gallery Section */}
          <div className="md:col-span-2">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-gray-900">
                  Your Files ({files.length})
                </h2>
                {isLoadingFiles && <Loader2 className="w-4 h-4 animate-spin text-gray-400" />}
              </div>

              {isLoadingFiles ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="w-8 h-8 animate-spin text-gray-400" />
                </div>
              ) : (
                <FileGallery
                  files={files}
                  onDelete={handleDelete}
                  isDeleting={deleteMutation.isPending}
                />
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
