import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, Leaf, Cloud, Headphones, TrendingUp, Upload } from "lucide-react";
import { getLoginUrl } from "@/const";

/**
 * 256ROOTS' VOICE - Home Page
 * Design: Modern Environmental Minimalism with Neon Accents
 * Color Palette: Gray (#6B7280), Neon Green (#39FF14 → #A8FF00), Coffee Brown (#6F4E37), White (#FFFFFF)
 * Typography: Poppins (bold display) + Inter (body)
 * Layout: Asymmetric hero-driven with staggered content blocks
 * Now with full-stack auth and file storage integration
 */

export default function Home() {
  const { user, isAuthenticated, logout } = useAuth();

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <Leaf className="w-8 h-8" style={{ color: "#39FF14" }} />
            <h1 className="text-2xl font-bold" style={{ color: "#6B7280" }}>
              256ROOTS' <span style={{ color: "#39FF14" }}>VOICE</span>
            </h1>
          </div>
          <nav className="hidden md:flex gap-8">
            <a href="#wildlife" className="text-gray-600 hover:text-gray-900 transition">
              Wildlife
            </a>
            <a href="#climate" className="text-gray-600 hover:text-gray-900 transition">
              Climate
            </a>
            <a href="#voices" className="text-gray-600 hover:text-gray-900 transition">
              Voices
            </a>
            <a href="#impact" className="text-gray-600 hover:text-gray-900 transition">
              Impact
            </a>
            {isAuthenticated && (
              <a href="/files" className="text-gray-600 hover:text-gray-900 transition flex items-center gap-1">
                <Upload className="w-4 h-4" />
                Files
              </a>
            )}
          </nav>
          <div className="flex items-center gap-3">
            {isAuthenticated ? (
              <>
                <span className="text-sm text-gray-600">{user?.name || user?.email}</span>
                <Button onClick={logout} variant="outline" className="text-xs">
                  Logout
                </Button>
              </>
            ) : (
              <Button onClick={() => (window.location.href = getLoginUrl())} className="btn-neon">
                Sign In
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage:
              "url('https://d2xsxph8kpxj0f.cloudfront.net/310519663432774693/ZuyquJjuysgd4pD3ekLrur/hero-uganda-wildlife-FDMtDtTmCdGZaFpEZKBR7j.webp')",
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-gray-900/60 via-gray-900/40 to-transparent"></div>
        </div>

        <div className="relative z-10 container max-w-4xl">
          <div className="space-y-6">
            <div className="inline-block px-4 py-2 rounded-full border border-green-400/30 bg-green-400/10">
              <p className="text-sm font-semibold neon-accent">Nurture the Nature</p>
            </div>
            <h1 className="text-6xl md:text-7xl font-bold text-white leading-tight">
              Locally Rooted,
              <br />
              <span style={{ color: "#39FF14" }}>Internationally Connected</span>
            </h1>
            <p className="text-xl text-gray-200 max-w-2xl">
              Bridge the gap between Uganda's rich natural heritage and global conservation efforts. Discover real-time wildlife data, climate insights, and stories that matter.
            </p>
            <div className="flex gap-4 pt-4">
              <Button className="btn-neon flex items-center gap-2">
                Explore Now <ArrowRight className="w-4 h-4" />
              </Button>
              <Button className="btn-outline-neon">Learn More</Button>
            </div>
          </div>
        </div>
      </section>

      {/* Wildlife Chronicle Section */}
      <section id="wildlife" className="py-20 bg-white">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h2 style={{ color: "#6F4E37" }}>Wildlife Chronicle</h2>
              <p className="text-lg text-gray-600">
                Explore high-definition profiles of Uganda's most iconic and endangered species. From mountain gorillas to African elephants, discover the stories of the creatures that call Uganda home.
              </p>
              <div className="space-y-4">
                <div className="flex gap-4">
                  <div
                    className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: "#39FF14", color: "#1F2937" }}
                  >
                    <Leaf className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">A-Z Species Directory</h3>
                    <p className="text-sm text-gray-600">Comprehensive profiles with conservation status and habitat maps</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div
                    className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: "#A8FF00", color: "#1F2937" }}
                  >
                    <TrendingUp className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Population Tracking</h3>
                    <p className="text-sm text-gray-600">Real-time conservation status and population trends</p>
                  </div>
                </div>
              </div>
              <Button className="btn-neon">Explore Species</Button>
            </div>
            <div className="rounded-2xl overflow-hidden shadow-lg">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663432774693/ZuyquJjuysgd4pD3ekLrur/wildlife-elephant-savanna-awhcRW8bTo3dzPvzf2eXxL.webp"
                alt="African Elephant in Uganda"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      <div className="section-divider"></div>

      {/* Climate Sync Section */}
      <section id="climate" className="py-20 bg-gradient-to-br from-gray-50 to-white">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="rounded-2xl overflow-hidden shadow-lg order-2 md:order-1">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663432774693/ZuyquJjuysgd4pD3ekLrur/climate-weather-dashboard-FwUgqMstye9NzjX4dsviQy.webp"
                alt="Climate Sync Dashboard"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="space-y-6 order-1 md:order-2">
              <h2 style={{ color: "#6F4E37" }}>Climate Sync</h2>
              <p className="text-lg text-gray-600">
                Live weather dashboards providing localized updates across Uganda's national parks. Understand how climate patterns directly impact local wildlife and community livelihoods.
              </p>
              <div className="space-y-4">
                <div className="flex gap-4">
                  <div
                    className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: "#39FF14", color: "#1F2937" }}
                  >
                    <Cloud className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Real-Time Data</h3>
                    <p className="text-sm text-gray-600">Temperature, rainfall, and climate trends across all parks</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div
                    className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: "#A8FF00", color: "#1F2937" }}
                  >
                    <TrendingUp className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Environmental Impact</h3>
                    <p className="text-sm text-gray-600">See how weather affects ecosystems and wildlife behavior</p>
                  </div>
                </div>
              </div>
              <Button className="btn-neon">View Dashboard</Button>
            </div>
          </div>
        </div>
      </section>

      <div className="section-divider"></div>

      {/* Voices of the Wild Section */}
      <section id="voices" className="py-20 bg-white">
        <div className="container">
          <div className="text-center mb-16">
            <h2 style={{ color: "#6F4E37" }} className="mb-4">
              Voices of the Wild
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Multimedia storytelling featuring interviews with rangers, activists, and environmental scientists
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: "Podcast Series",
                description: "Deep conversations with conservation leaders and field experts",
                icon: Headphones,
              },
              {
                title: "Photo Gallery",
                description: "Stunning wildlife and landscape photography from Uganda",
                icon: Leaf,
              },
              {
                title: "Blog Articles",
                description: "In-depth environmental education and conservation insights",
                icon: TrendingUp,
              },
            ].map((item, idx) => (
              <Card key={idx} className="card-elevated">
                <div className="flex flex-col h-full">
                  <div
                    className="w-14 h-14 rounded-lg flex items-center justify-center mb-4"
                    style={{ backgroundColor: "#39FF14", color: "#1F2937" }}
                  >
                    <item.icon className="w-7 h-7" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{item.title}</h3>
                  <p className="text-gray-600 flex-grow">{item.description}</p>
                  <button className="mt-4 text-neon-green font-semibold hover:translate-x-1 transition-transform flex items-center gap-2">
                    Explore <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <div className="section-divider"></div>

      {/* Green Action Section */}
      <section id="impact" className="py-20 bg-gradient-to-br from-gray-50 to-white">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h2 style={{ color: "#6F4E37" }}>Green Action Portal</h2>
              <p className="text-lg text-gray-600">
                Connect with active reforestation projects and conservation initiatives. Whether you're an international donor or a local volunteer, find ways to make a tangible impact on Uganda's natural heritage.
              </p>
              <div className="space-y-4">
                <div className="flex gap-4">
                  <div
                    className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: "#39FF14", color: "#1F2937" }}
                  >
                    <TrendingUp className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Impact Tracker</h3>
                    <p className="text-sm text-gray-600">Visual counter showing trees planted and wildlife populations stabilized</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div
                    className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: "#A8FF00", color: "#1F2937" }}
                  >
                    <Leaf className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Project Directory</h3>
                    <p className="text-sm text-gray-600">Browse active conservation and reforestation initiatives</p>
                  </div>
                </div>
              </div>
              <Button className="btn-neon">Join a Project</Button>
            </div>
            <div className="rounded-2xl overflow-hidden shadow-lg">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663432774693/ZuyquJjuysgd4pD3ekLrur/conservation-impact-bviFFZ7EsBs2w2YXiPZaqw.webp"
                alt="Conservation Impact"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      <div className="section-divider"></div>

      {/* CTA Section */}
      <section className="py-20 bg-white">
        <div className="container text-center">
          <h2 style={{ color: "#6F4E37" }} className="mb-6">
            Ready to Amplify Nature's Voice?
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
            Join thousands of digital conservationists protecting Uganda's natural beauty and engaging with global conservation efforts.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            {isAuthenticated ? (
              <a href="/files">
                <Button className="btn-neon">Upload Content</Button>
              </a>
            ) : (
              <Button onClick={() => (window.location.href = getLoginUrl())} className="btn-neon">
                Get Started Today
              </Button>
            )}
            <Button className="btn-outline-neon">Learn More</Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer
        className="py-12 text-white"
        style={{ backgroundColor: "#6F4E37" }}
      >
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4 flex items-center gap-2">
                <Leaf className="w-5 h-5" style={{ color: "#39FF14" }} />
                256ROOTS' VOICE
              </h4>
              <p className="text-sm text-gray-200">
                Nurture the Nature: Locally Rooted, Internationally Connected
              </p>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Explore</h5>
              <ul className="space-y-2 text-sm text-gray-200">
                <li><a href="#wildlife" className="hover:text-white transition">Wildlife</a></li>
                <li><a href="#climate" className="hover:text-white transition">Climate</a></li>
                <li><a href="#voices" className="hover:text-white transition">Voices</a></li>
                <li><a href="#impact" className="hover:text-white transition">Impact</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Resources</h5>
              <ul className="space-y-2 text-sm text-gray-200">
                <li><a href="#" className="hover:text-white transition">Blog</a></li>
                <li><a href="#" className="hover:text-white transition">Podcasts</a></li>
                <li><a href="#" className="hover:text-white transition">Gallery</a></li>
                <li><a href="#" className="hover:text-white transition">Contact</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Connect</h5>
              <ul className="space-y-2 text-sm text-gray-200">
                <li><a href="#" className="hover:text-white transition">Twitter</a></li>
                <li><a href="#" className="hover:text-white transition">Instagram</a></li>
                <li><a href="#" className="hover:text-white transition">Facebook</a></li>
                <li><a href="#" className="hover:text-white transition">LinkedIn</a></li>
              </ul>
            </div>
          </div>
          <div
            className="border-t border-white/20 pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-gray-200"
          >
            <p>&copy; 2026 256ROOTS' VOICE. All rights reserved.</p>
            <div className="flex gap-6 mt-4 md:mt-0">
              <a href="#" className="hover:text-white transition">Privacy Policy</a>
              <a href="#" className="hover:text-white transition">Terms of Service</a>
              <a href="#" className="hover:text-white transition">Accessibility</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
