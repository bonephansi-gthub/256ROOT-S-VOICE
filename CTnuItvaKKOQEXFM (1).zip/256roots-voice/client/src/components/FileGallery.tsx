import { File as FileType } from "@shared/types";
import { Download, Trash2, FileText, Music, Image as ImageIcon, FileQuestion } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";

interface FileGalleryProps {
  files: FileType[];
  onDelete: (fileId: number) => void;
  isDeleting?: boolean;
}

const getCategoryIcon = (category: string) => {
  switch (category) {
    case "photo":
    case "wildlife":
      return <ImageIcon className="w-5 h-5" />;
    case "podcast":
      return <Music className="w-5 h-5" />;
    case "document":
      return <FileText className="w-5 h-5" />;
    default:
      return <FileQuestion className="w-5 h-5" />;
  }
};

const getCategoryColor = (category: string) => {
  switch (category) {
    case "wildlife":
      return "bg-green-100 text-green-700";
    case "podcast":
      return "bg-blue-100 text-blue-700";
    case "document":
      return "bg-orange-100 text-orange-700";
    case "photo":
      return "bg-purple-100 text-purple-700";
    default:
      return "bg-gray-100 text-gray-700";
  }
};

const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + " " + sizes[i];
};

const formatDate = (date: Date): string => {
  return new Date(date).toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
};

export default function FileGallery({ files, onDelete, isDeleting = false }: FileGalleryProps) {
  if (files.length === 0) {
    return (
      <div className="text-center py-12">
        <FileQuestion className="w-12 h-12 mx-auto text-gray-300 mb-4" />
        <p className="text-gray-500">No files uploaded yet</p>
        <p className="text-sm text-gray-400">Start by uploading your first file above</p>
      </div>
    );
  }

  return (
    <div className="grid gap-4">
      {files.map((file) => (
        <Card key={file.id} className="card-elevated">
          <div className="flex items-start justify-between gap-4">
            {/* File Info */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-3 mb-2">
                <div className={`p-2 rounded-lg ${getCategoryColor(file.category)}`}>
                  {getCategoryIcon(file.category)}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-gray-900 truncate">{file.fileName}</h3>
                  <p className="text-xs text-gray-500">
                    {formatFileSize(file.fileSize)} • {formatDate(file.uploadedAt)}
                  </p>
                </div>
              </div>

              {/* Category Badge */}
              <div className="flex items-center gap-2 mb-2">
                <span className={`inline-block px-2 py-1 rounded text-xs font-medium ${getCategoryColor(file.category)}`}>
                  {file.category}
                </span>
              </div>

              {/* Description */}
              {file.description && (
                <p className="text-sm text-gray-600 line-clamp-2">{file.description}</p>
              )}
            </div>

            {/* Actions */}
            <div className="flex gap-2 flex-shrink-0">
              <a
                href={file.fileUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => {
                  // Try to download instead of open
                  const link = document.createElement("a");
                  link.href = file.fileUrl;
                  link.download = file.fileName;
                  document.body.appendChild(link);
                  link.click();
                  document.body.removeChild(link);
                  e.preventDefault();
                }}
              >
                <Button
                  variant="outline"
                  size="sm"
                  className="gap-1"
                  title="Download file"
                >
                  <Download className="w-4 h-4" />
                  <span className="hidden sm:inline">Download</span>
                </Button>
              </a>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  onDelete(file.id);
                }}
                disabled={isDeleting}
                className="gap-1 text-red-600 hover:text-red-700 hover:bg-red-50"
                title="Delete file"
              >
                <Trash2 className="w-4 h-4" />
                <span className="hidden sm:inline">Delete</span>
              </Button>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}
