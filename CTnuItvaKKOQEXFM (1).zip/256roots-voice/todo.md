# 256ROOTS' VOICE - Full-Stack Upgrade TODO

## Phase 1: Full-Stack Upgrade
- [x] Upgrade project to web-db-user template
- [x] Database schema initialized with users table
- [x] Resolve Home.tsx conflict (keep existing design, add auth integration)
- [x] Database migrations pushed (pnpm db:push)
- [x] Dev server restarted and verified

## Phase 2: File Storage Integration
- [x] Create files table in database schema
- [x] Add file upload procedure in server/routers.ts
- [x] Add file list procedure in server/routers.ts
- [x] Add file delete procedure in server/routers.ts
- [x] Create FileUpload component with drag-and-drop support
- [x] Create FileGallery component to display uploaded files
- [x] Create FileManager page (Files.tsx) with upload and gallery
- [x] Add file storage route to App.tsx navigation

## Phase 3: File Management Features
- [x] Implement file categorization (wildlife, podcast, document, photo, other)
- [ ] Add file search and filtering
- [ ] Implement file preview for images
- [x] Add file download functionality
- [ ] Create file sharing/access control
- [ ] Add file metadata editing

## Phase 4: Testing & Deployment
- [x] Write comprehensive vitest tests for file procedures (15 tests)
- [x] Test file upload validation and error handling
- [x] Test file list functionality
- [x] Test file deletion with authorization checks
- [x] Test authentication requirements
- [x] Verify all tests pass (15/15 passing)
- [ ] Create checkpoint before deployment
