import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { uploadFile, getUserFiles, deleteFile } from "./db";
import { storagePut } from "./storage";
import { nanoid } from "nanoid";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  files: router({
    /**
     * Upload a file to S3 and store metadata in database
     * Input: base64 encoded file data, filename, mimetype, category, description
     */
    upload: protectedProcedure
      .input(
        z.object({
          fileName: z.string().min(1).max(255),
          fileData: z.string(), // base64 encoded
          mimeType: z.string().max(100),
          category: z.enum(["wildlife", "podcast", "document", "photo", "other"]),
          description: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        try {
          // Decode base64 to buffer
          const buffer = Buffer.from(input.fileData, "base64");
          const fileSize = buffer.length;

          // Create unique file key with random suffix to prevent enumeration
          const fileKey = `${ctx.user.id}-files/${input.fileName}-${nanoid()}.bin`;

          // Upload to S3
          const { url } = await storagePut(fileKey, buffer, input.mimeType);

          // Store metadata in database
          const file = await uploadFile({
            userId: ctx.user.id,
            fileName: input.fileName,
            fileKey,
            fileUrl: url,
            mimeType: input.mimeType,
            fileSize,
            category: input.category,
            description: input.description || null,
          });

          return file;
        } catch (error) {
          console.error("[Files] Upload failed:", error);
          throw new Error("Failed to upload file");
        }
      }),

    /**
     * List all files for the current user
     */
    list: protectedProcedure.query(async ({ ctx }) => {
      try {
        const userFiles = await getUserFiles(ctx.user.id);
        return userFiles;
      } catch (error) {
        console.error("[Files] List failed:", error);
        throw new Error("Failed to list files");
      }
    }),

    /**
     * Delete a file (only owner can delete)
     */
    delete: protectedProcedure
      .input(z.object({ fileId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        try {
          const success = await deleteFile(input.fileId, ctx.user.id);
          return { success };
        } catch (error) {
          console.error("[Files] Delete failed:", error);
          throw new Error("Failed to delete file");
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
