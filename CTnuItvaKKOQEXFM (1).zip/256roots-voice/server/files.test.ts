import { describe, expect, it, beforeEach, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import type { User } from "../drizzle/schema";

// Mock the storage module
vi.mock("./storage", () => ({
  storagePut: vi.fn().mockResolvedValue({
    key: "test-key-123",
    url: "https://example.com/test-file.bin",
  }),
}));

// Mock the database module
vi.mock("./db", () => ({
  uploadFile: vi.fn().mockResolvedValue({
    id: 1,
    userId: 1,
    fileName: "test.jpg",
    fileKey: "1-files/test.jpg-abc123.bin",
    fileUrl: "https://example.com/test-file.bin",
    mimeType: "image/jpeg",
    fileSize: 1024,
    category: "photo",
    description: "Test photo",
    uploadedAt: new Date(),
    updatedAt: new Date(),
  }),
  getUserFiles: vi.fn().mockResolvedValue([
    {
      id: 1,
      userId: 1,
      fileName: "test.jpg",
      fileKey: "1-files/test.jpg-abc123.bin",
      fileUrl: "https://example.com/test-file.bin",
      mimeType: "image/jpeg",
      fileSize: 1024,
      category: "photo",
      description: "Test photo",
      uploadedAt: new Date(),
      updatedAt: new Date(),
    },
  ]),
  deleteFile: vi.fn().mockResolvedValue(true),
}));

function createAuthContext(userId = 1): { ctx: TrpcContext } {
  const user: User = {
    id: userId,
    openId: `user-${userId}`,
    email: `user${userId}@example.com`,
    name: `User ${userId}`,
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

describe("files router", () => {
  describe("files.upload", () => {
    it("should upload a file successfully", async () => {
      const { ctx } = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.files.upload({
        fileName: "test.jpg",
        fileData: Buffer.from("test data").toString("base64"),
        mimeType: "image/jpeg",
        category: "photo",
        description: "Test photo",
      });

      expect(result).toBeDefined();
      expect(result?.fileName).toBe("test.jpg");
      expect(result?.category).toBe("photo");
      expect(result?.description).toBe("Test photo");
    });

    it("should validate required fields", async () => {
      const { ctx } = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.files.upload({
          fileName: "",
          fileData: Buffer.from("test data").toString("base64"),
          mimeType: "image/jpeg",
          category: "photo",
        });
        expect.fail("Should have thrown validation error");
      } catch (error: any) {
        expect(error.message).toContain("Too small");
      }
    });

    it("should validate category enum", async () => {
      const { ctx } = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.files.upload({
          fileName: "test.jpg",
          fileData: Buffer.from("test data").toString("base64"),
          mimeType: "image/jpeg",
          category: "invalid" as any,
        });
        expect.fail("Should have thrown validation error");
      } catch (error: any) {
        expect(error.message).toContain("Invalid option");
      }
    });

    it("should handle file upload errors gracefully", async () => {
      const { storagePut } = await import("./storage");
      vi.mocked(storagePut).mockRejectedValueOnce(new Error("Upload failed"));

      const { ctx } = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.files.upload({
          fileName: "test.jpg",
          fileData: Buffer.from("test data").toString("base64"),
          mimeType: "image/jpeg",
          category: "photo",
        });
        expect.fail("Should have thrown error");
      } catch (error: any) {
        expect(error.message).toContain("Failed to upload file");
      }
    });
  });

  describe("files.list", () => {
    it("should list user files", async () => {
      const { ctx } = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.files.list();

      expect(Array.isArray(result)).toBe(true);
      expect(result.length).toBeGreaterThan(0);
      expect(result[0]?.userId).toBe(1);
    });

    it("should return empty array when no files exist", async () => {
      const { getUserFiles } = await import("./db");
      vi.mocked(getUserFiles).mockResolvedValueOnce([]);

      const { ctx } = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.files.list();

      expect(Array.isArray(result)).toBe(true);
      expect(result.length).toBe(0);
    });

    it("should handle database errors gracefully", async () => {
      const { getUserFiles } = await import("./db");
      vi.mocked(getUserFiles).mockRejectedValueOnce(new Error("Database error"));

      const { ctx } = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.files.list();
        expect.fail("Should have thrown error");
      } catch (error: any) {
        expect(error.message).toContain("Failed to list files");
      }
    });
  });

  describe("files.delete", () => {
    it("should delete a file successfully", async () => {
      const { ctx } = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.files.delete({ fileId: 1 });

      expect(result.success).toBe(true);
    });

    it("should validate fileId input", async () => {
      const { ctx } = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.files.delete({ fileId: "invalid" as any });
        expect.fail("Should have thrown validation error");
      } catch (error: any) {
        expect(error.message).toContain("Invalid input");
      }
    });

    it("should handle delete errors gracefully", async () => {
      const { deleteFile } = await import("./db");
      vi.mocked(deleteFile).mockRejectedValueOnce(new Error("Delete failed"));

      const { ctx } = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.files.delete({ fileId: 1 });
        expect.fail("Should have thrown error");
      } catch (error: any) {
        expect(error.message).toContain("Failed to delete file");
      }
    });

    it("should only allow user to delete their own files", async () => {
      const { deleteFile } = await import("./db");
      vi.mocked(deleteFile).mockResolvedValueOnce(false); // Simulates file not found or unauthorized

      const { ctx } = createAuthContext(1);
      const caller = appRouter.createCaller(ctx);

      const result = await caller.files.delete({ fileId: 999 });

      expect(result.success).toBe(false);
    });
  });

  describe("authentication", () => {
    it("should require authentication for upload", async () => {
      const caller = appRouter.createCaller({ user: null } as any);

      try {
        await caller.files.upload({
          fileName: "test.jpg",
          fileData: Buffer.from("test data").toString("base64"),
          mimeType: "image/jpeg",
          category: "photo",
        });
        expect.fail("Should have thrown authentication error");
      } catch (error: any) {
        expect(error.message).toContain("Please login");
      }
    });

    it("should require authentication for list", async () => {
      const caller = appRouter.createCaller({ user: null } as any);

      try {
        await caller.files.list();
        expect.fail("Should have thrown authentication error");
      } catch (error: any) {
        expect(error.message).toContain("Please login");
      }
    });

    it("should require authentication for delete", async () => {
      const caller = appRouter.createCaller({ user: null } as any);

      try {
        await caller.files.delete({ fileId: 1 });
        expect.fail("Should have thrown authentication error");
      } catch (error: any) {
        expect(error.message).toContain("Please login");
      }
    });
  });
});
