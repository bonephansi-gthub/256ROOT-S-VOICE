# 256ROOTS' VOICE - Design Brainstorm

## Design Approach Selected: Modern Environmental Minimalism with Neon Accents

### Design Movement
**Modern Environmental Minimalism** merged with **Cyberpunk Naturalism** — a contemporary aesthetic that combines clean, purposeful design with striking neon accents to symbolize the intersection of technology and nature.

### Core Principles

1. **Purposeful Simplicity**: Every element serves a function. Whitespace is abundant and deliberate, allowing content to breathe and command attention.
2. **Nature-Tech Fusion**: The design bridges the organic world (wildlife, weather) with digital innovation through color and typography choices.
3. **Accessibility First**: High contrast ratios, clear hierarchy, and readable typography ensure the platform is inclusive and engaging for all audiences.
4. **Emotional Storytelling**: Visual elements guide users through a narrative of conservation, urgency, and hope—not through clutter, but through strategic emphasis.

### Color Philosophy

The color palette reflects the duality of Uganda's natural heritage and the digital urgency of conservation:

- **Gray (#6B7280)**: The foundation—neutral, trustworthy, representing stability and scientific rigor.
- **Fading Neon Green (#39FF14 → #A8FF00)**: A gradient representing vitality, growth, and the "voice" of nature emerging from the digital landscape. This is the primary accent for CTAs and highlights.
- **Coffee Brown (#6F4E37)**: Warm, earthy, grounding—connecting users to Uganda's soil and natural heritage.
- **White (#FFFFFF)**: Clean, open, and accessible—the primary background that allows content to shine.

**Emotional Intent**: The neon green against gray and white creates urgency and hope simultaneously—a call to action wrapped in optimism.

### Layout Paradigm

**Asymmetric Hero-Driven Layout** with **Staggered Content Blocks**:
- Hero section spans full width with a striking background image (wildlife or landscape) overlaid with semi-transparent gradient.
- Content sections alternate between left-aligned text with right-aligned imagery and vice versa, creating visual rhythm.
- No rigid grid; instead, sections flow organically with varied widths and asymmetric spacing.
- Floating accent elements (neon green lines, organic shapes) guide the eye without overwhelming.

### Signature Elements

1. **Neon Green Accent Lines**: Thin, glowing green lines separate sections and highlight key information—evoking both digital interfaces and natural growth patterns.
2. **Organic Shape Dividers**: SVG dividers between sections use flowing, wave-like patterns (not sharp angles) to represent water, wind, and natural movement.
3. **Typography Contrast**: Bold, large display fonts for headlines (creating visual dominance) paired with clean, readable sans-serif for body text.

### Interaction Philosophy

- **Hover States**: Neon green glows and subtle scale transforms on interactive elements.
- **Scroll Animations**: Elements fade in and slide gently as users scroll, creating a sense of discovery.
- **Micro-interactions**: Buttons respond with smooth color transitions; cards lift slightly on hover.
- **Loading States**: Animated neon green lines suggest progress and activity without distraction.

### Animation Guidelines

- **Entrance Animations**: Content fades in from opacity 0 with a gentle upward translate (200-300ms duration).
- **Hover Effects**: Interactive elements glow with a subtle neon green box-shadow and scale up by 1.02x.
- **Scroll Triggers**: Sections animate in as they enter the viewport (using Intersection Observer patterns).
- **Accent Animations**: Neon green lines subtly pulse or glow to draw attention without being jarring.

### Typography System

- **Display Font**: "Poppins" (bold, 700-900 weights) for headlines and hero text. Modern, geometric, and energetic.
- **Body Font**: "Inter" (400-600 weights) for body text and descriptions. Clean, highly readable, professional.
- **Hierarchy**:
  - H1: Poppins, 48-64px, bold, color: gray or coffee brown
  - H2: Poppins, 32-40px, semi-bold, color: coffee brown
  - H3: Poppins, 24-28px, semi-bold, color: gray
  - Body: Inter, 16px, regular, color: gray
  - Small: Inter, 14px, regular, color: gray (muted)

---

## Implementation Notes

- All design decisions reinforce the theme: **Nurture the Nature: Locally Rooted, Internationally Connected**.
- The neon green is the "voice"—it appears strategically to highlight CTAs, key statistics, and calls to action.
- Coffee brown grounds the design, appearing in section backgrounds and text to maintain connection to Uganda's natural heritage.
- White space is generous to ensure the content—wildlife stories, weather data, conservation impact—is the true star.
